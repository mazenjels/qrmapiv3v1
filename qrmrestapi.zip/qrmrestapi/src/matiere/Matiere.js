let niveaux = require ('../niveau/Niveau');
class Matiere{


    id='';
    name='';
    description='';
    activeStatus=0;
	niveau = niveaux.Niveau;


    constructor() {

	}

     getId() {
		return this.id;
	}



	getActiveStatus() {
		return this.activeStatus;
	}



	setActiveStatus( activeStatus) {
		this.activeStatus = activeStatus;
	}



	setId( id) {
		this.id = id;
	}



	getName() {
		return this.name;
	}

	setName( name) {
		this.name = name;
	}

	getDescription() {
		return this.description;
	}

	setDescription( description) {
		
		this.description = description;
	}

	getNiveau() {
		return this.niveau;
	}

	setNiveau( niveau) {
		this.niveau = niveau;
	}

}


module.exports = {
    Matiere:Matiere
};