const getAllMatieres = "SELECT * FROM public.tb_matiere order by matiere_create_datetime desc";
const getMatiereById = "SELECT * FROM public.tb_matiere WHERE matiere_id=$1::uuid";
const checkIfMatiereExists = "SELECT n from public.tb_matiere n where n.matiere_name=$1";
const addMatiere = "INSERT INTO public.tb_matiere(matiere_name, matiere_description) VALUES ($1,$2)";
const removeMatiere = "DELETE FROM public.tb_matiere WHERE matiere_id=$1::uuid";
const updateMatiere = "UPDATE  public.tb_matiere SET matiere_name=$1, matiere_description=$2 WHERE matiere_id=$3::uuid";

module.exports = {
    getAllMatieres,
    getMatiereById,
    checkIfMatiereExists,
    addMatiere,
    removeMatiere,
    updateMatiere,
}