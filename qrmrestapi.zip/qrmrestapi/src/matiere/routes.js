const{Router} = require('express');
const res = require('express/lib/response');
const router  = new Router();
const controller = require('./controller');

router.get('/matieres/list',controller.getMatieres);
router.get("/matieres/get/:matiere_id", controller.getMatiereById);
router.post("/matieres/add",controller.addMatiere);
router.delete("/matieres/delete/:matiere_id", controller.removeMatiere);
router.put("/matieres/update/:matiere_id", controller.updateMatiere);


module.exports = router;