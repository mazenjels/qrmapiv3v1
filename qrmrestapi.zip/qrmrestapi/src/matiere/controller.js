const pool = require('../../db');
const queries = require('./queries');
let matieres = require ('./Matiere.js');
let niveaux = require ('../niveau/Niveau.js');

let matiere = matieres.Matiere;
let niveau = niveaux.Niveau;

const getMatieres = (req,res)=>{
    //console.log('Getting matieres');
    

    pool.query(queries.getAllMatieres,(error,results)=>{
        if(error) throw error;
        var arr = [];
        var mat = new matiere();
        let ListMatieres = Array();
        var index = 0;
        results.rows.forEach(row => {
            
            mat = new matiere();
          //console.log(results.rows[index].matiere_name);
          mat.setId(results.rows[index].matiere_id);
          mat.setName(results.rows[index].matiere_designation);
          mat.setDescription(results.rows[index].matiere_description);
          mat.setActiveStatus(results.rows[index].matiere_active_status);
            ListMatieres.push(mat);
            index++;
        });
        res.status(200).json(ListMatieres);
    })
};

const getMatiereById = (req,res)=>{
    const mat = new matiere();
    const niv = new niveau();
    mat.setId(req.params.matiere_id);
    //const matiereId = req.params.matiere_id;
    pool.query(queries.getMatiereById,[mat.getId()],(error, results)=>{
        if(error) throw error;

       // console.log('Matiere name : '+results.rows[0].matiere_name);
        niv.setId(results.rows[0].niveau_id);

        mat.setNiveau(niv);
        mat.setId(results.rows[0].matiere_id);
        mat.setName(results.rows[0].matiere_designation);
        mat.setDescription(results.rows[0].matiere_description);
        mat.setActiveStatus(results.rows[0].matiere_active_status);
        res.status(200).json(mat);
    })
}

const addMatiere = (req,res)=>{
    const {matiere_name,matiere_description} = req.body;

    //Check if matiere exists
    pool.query(queries.checkIfMatiereExists,[matiere_name],(error, results)=>{
        if(results.rows.length){
            res.send("le matiere "+matiere_name+" existe deja.");
        }

        //Add matiere to database
        pool.query(queries.addMatiere,[matiere_name,matiere_description],(error,results)=>{
            if(error) throw error;
            res.status(200).send("Nouveau matiere ajouté.");
        });
    });
};

const removeMatiere = (req,res)=>{
    const matiereId = req.params.matiere_id;

    pool.query(queries.getMatiereById,[matiereId],(error, results)=>{
        const noMatiereFound = !results.rows.length;
        if(noMatiereFound){
            res.send("Le matiere n'existe pas");
        }

        pool.query(queries.removeMatiere,[matiereId],(error, results)=>{
            if(error) throw error;
    
            res.status(200).send("Matiere  supprimé avec succès.");

        });
             
    });
};

const updateMatiere = (req,res)=>{
    const matiereId = req.params.matiere_id;
    const {matiere_name,matiere_description} = req.body;

    pool.query(queries.getMatiereById,[matiereId],(error,results)=>{
        const noMatiereFound = !results.rows.length;
        if(noMatiereFound){
            res.send("Le matiere n'existe pas");
        }

        pool.query(queries.updateMatiere,[matiere_name,matiere_description,matiereId],(error, results)=>{
            if(error) throw error;
    
            res.status(200).send("Matiere  mis a jour.");

        });
    });
};

module.exports = {
    getMatieres,
    getMatiereById,
    addMatiere,
    removeMatiere,
    updateMatiere,
}
