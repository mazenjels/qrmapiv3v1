const pool = require('../../db');
const queries = require('./queries');
let etatCivils = require ('./EtatCivil.js');

let etatCivil = etatCivils.EtatCivil;


const getEtatCivils = (req,res)=>{
    

    pool.query(queries.getAllEtatCivils,(error,results)=>{
        if(error) throw error;
        var arr = [];
        var et_civ = new etatCivil();
        let ListEtatCivil = Array();
        var index = 0;
        results.rows.forEach(row => {
            
            et_civ = new etatCivil();
          //console.log(results.rows[index].niveau_name);
          et_civ.setId(results.rows[index].etat_civil_id);
          et_civ.setDesignation(results.rows[index].etat_civil_designation);
          et_civ.setActiveStatus(results.rows[index].etat_civil_active_status);
          ListEtatCivil.push(et_civ);
            index++;
        });
        res.status(200).json(ListEtatCivil);
    })
};


module.exports = {
    getEtatCivils,
   
}
