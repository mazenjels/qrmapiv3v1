const getAllEtatCivils = "select * from public.tb_etat_civil where etat_civil_active_status=1";


module.exports = {
    getAllEtatCivils,
}