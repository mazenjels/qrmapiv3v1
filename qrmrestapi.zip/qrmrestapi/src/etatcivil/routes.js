const{Router} = require('express');
const res = require('express/lib/response');
const router  = new Router();
const controller = require('./controller');

router.get('/etatCivil/list',controller.getEtatCivils);


module.exports = router;