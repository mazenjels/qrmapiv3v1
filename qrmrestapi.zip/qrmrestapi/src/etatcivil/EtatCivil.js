class EtatCivil{

    id='';
    designation='';
    activeStatus=0;

    constructor() {

	}

     getId() {
		return this.id;
	}
	getActiveStatus() {
		return this.activeStatus;
	}

	setActiveStatus( activeStatus) {
		this.activeStatus = activeStatus;
	}

	setId( id) {
		this.id = id;
	}



	getDesignation() {
		return this.designation;
	}

	setDesignation( designation) {
		this.designation = designation;
	}

}


module.exports = {
    EtatCivil:EtatCivil
};