const pool = require('../../db');
const queries = require('./queries');
let niveaux = require ('./Niveau.js');
let matieres = require ('../matiere/Matiere.js');
//const Matiere = require('../matiere/Matiere.js');

let niveau = niveaux.Niveau;
let matiere = matieres.Matiere;

const getNiveaux = (req,res)=>{
    //console.log('Getting niveaux');
    

    pool.query(queries.getAllNiveaux,(error,results)=>{
        if(error) throw error;
        var arr = [];
        var niv = new niveau();
        let ListNiveaux = Array();
        var index = 0;
        results.rows.forEach(row => {
            
            niv = new niveau();
          //console.log(results.rows[index].niveau_name);
            niv.setId(results.rows[index].niveau_id);
            niv.setName(results.rows[index].niveau_name);
            niv.setDescription(results.rows[index].niveau_description);
            niv.setActiveStatus(results.rows[index].niveau_active_status);
            ListNiveaux.push(niv);
            index++;
        });
        res.status(200).json(ListNiveaux);
    })
};

const getNiveauById = (req,res)=>{
    const niv = new niveau();
    var mat = new matiere();
    var listMatieres = Array();
    niv.setId(req.params.niveau_id);
    //const niveauId = req.params.niveau_id;
    pool.query(queries.getNiveauById,[niv.getId()],(error, results)=>{
        if(error) throw error;

       // console.log('Niveau name : '+results.rows[0].niveau_name);
       results.rows.forEach(row=>{
            mat = new matiere();
            mat.setId(results.rows[0].matiere_id);
            mat.setName(results.rows[0].matiere_designation);
            mat.setDescription(results.rows[0].matiere_description);

            listMatieres.push(mat);
       })
        niv.setMatieres(listMatieres);
        niv.setId(results.rows[0].niveau_id);
        niv.setName(results.rows[0].niveau_name);
        niv.setDescription(results.rows[0].niveau_description);
        niv.setActiveStatus(results.rows[0].niveau_active_status);
        res.status(200).json(niv);
    })
}

const addNiveau = (req,res)=>{
    const {niveau_name,niveau_description} = req.body;

    //Check if niveau exists
    pool.query(queries.checkIfNiveauExists,[niveau_name],(error, results)=>{
        if(results.rows.length){
            res.send("le niveau "+niveau_name+" existe deja.");
        }

        //Add niveau to database
        pool.query(queries.addNiveau,[niveau_name,niveau_description],(error,results)=>{
            if(error) throw error;
            res.status(200).send("Nouveau niveau ajouté.");
        });
    });
};

const removeNiveau = (req,res)=>{
    const niveauId = req.params.niveau_id;

    pool.query(queries.getNiveauById,[niveauId],(error, results)=>{
        const noNiveauFound = !results.rows.length;
        if(noNiveauFound){
            res.send("Le niveau n'existe pas");
        }

        pool.query(queries.removeNiveau,[niveauId],(error, results)=>{
            if(error) throw error;
    
            res.status(200).send("Niveau  supprimé avec succès.");

        });
             
    });
};

const updateNiveau = (req,res)=>{
    const niveauId = req.params.niveau_id;
    const {niveau_name,niveau_description} = req.body;

    pool.query(queries.getNiveauById,[niveauId],(error,results)=>{
        const noNiveauFound = !results.rows.length;
        if(noNiveauFound){
            res.send("Le niveau n'existe pas");
        }

        pool.query(queries.updateNiveau,[niveau_name,niveau_description,niveauId],(error, results)=>{
            if(error) throw error;
    
            res.status(200).send("Niveau  mis a jour.");

        });
    });
};

module.exports = {
    getNiveaux,
    getNiveauById,
    addNiveau,
    removeNiveau,
    updateNiveau,
}
