class Niveau{

    // constructor(id,name, description) {
	// 	this.id = id;
	// 	this.name = name;
	// 	this.description = description;
	// }

    // constructor(name, description) {
	// 	this.name = name;
	// 	this.description = description;
	// }

    id='';
    name='';
    description='';
    activeStatus=0;
	matieres  = Array();


    constructor() {

	}

	getMatieres() {
		return this.matieres;
	}
	setMatieres( matieres) {
		this.matieres = matieres;
	}

     getId() {
		return this.id;
	}
	getActiveStatus() {
		return this.activeStatus;
	}



	setActiveStatus( activeStatus) {
		this.activeStatus = activeStatus;
	}



	setId( id) {
		this.id = id;
	}



	getName() {
		return this.name;
	}

	setName( name) {
		this.name = name;
	}

	getDescription() {
		return this.description;
	}

	setDescription( description) {
		this.description = description;
	}

}


module.exports = {
    Niveau:Niveau
};