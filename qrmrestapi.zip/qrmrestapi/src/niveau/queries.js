const getAllNiveaux = "select * from public.tb_niveau where niveau_active_status=1  order by niveau_name asc";

const getNiveauById = "SELECT * FROM public.vw_matiere_niveau WHERE niveau_id=$1::uuid and matiere_active_status=1";
const checkIfNiveauExists = "SELECT n from public.tb_niveau n where n.niveau_name=$1";
const addNiveau = "INSERT INTO public.tb_niveau(niveau_name, niveau_description) VALUES ($1,$2)";
const removeNiveau = "DELETE FROM public.tb_niveau WHERE niveau_id=$1::uuid";
const updateNiveau = "UPDATE  public.tb_niveau SET niveau_name=$1, niveau_description=$2 WHERE niveau_id=$3::uuid";

module.exports = {
    getAllNiveaux,
    getNiveauById,
    checkIfNiveauExists,
    addNiveau,
    removeNiveau,
    updateNiveau,
}