const{Router} = require('express');
const res = require('express/lib/response');
const router  = new Router();
const controller = require('./controller');

router.get('/niveaux/list',controller.getNiveaux);
router.get("/niveaux/get/:niveau_id", controller.getNiveauById);
router.post("/niveaux/add",controller.addNiveau);
router.delete("/niveaux/delete/:niveau_id", controller.removeNiveau);
router.put("/niveaux/update/:niveau_id", controller.updateNiveau);


module.exports = router;